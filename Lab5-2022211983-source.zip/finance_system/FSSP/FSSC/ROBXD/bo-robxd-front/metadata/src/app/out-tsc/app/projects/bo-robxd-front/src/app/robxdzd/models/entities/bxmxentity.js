import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var BXMXEntity = /** @class */ (function (_super) {
    tslib_1.__extends(BXMXEntity, _super);
    function BXMXEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BXMXEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ParentID',
            dataField: 'parentID',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ParentID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BXMXEntity.prototype, "parentID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillDetailDate',
            dataField: 'billDetailDate',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'BillDetailDate',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], BXMXEntity.prototype, "billDetailDate", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillDetailAmount',
            dataField: 'billDetailAmount',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'BillDetailAmount',
        }),
        tslib_1.__metadata("design:type", Object)
    ], BXMXEntity.prototype, "billDetailAmount", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillDetailNote',
            dataField: 'billDetailNote',
            originalDataFieldType: 'Text',
            initValue: '',
            path: 'BillDetailNote',
        }),
        tslib_1.__metadata("design:type", Object)
    ], BXMXEntity.prototype, "billDetailNote", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'InvoiceNO',
            dataField: 'invoiceNO',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'InvoiceNO',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BXMXEntity.prototype, "invoiceNO", void 0);
    BXMXEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "BXMX",
            nodeCode: "bxmxs"
        })
    ], BXMXEntity);
    return BXMXEntity;
}(Entity));
export { BXMXEntity };
