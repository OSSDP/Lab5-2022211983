import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var AttachmentInfo13b8Entity = /** @class */ (function (_super) {
    tslib_1.__extends(AttachmentInfo13b8Entity, _super);
    function AttachmentInfo13b8Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'AttachmentId',
            dataField: 'attachmentId',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'FileInfo.AttachmentId',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], AttachmentInfo13b8Entity.prototype, "attachmentId", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'FileName',
            dataField: 'fileName',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'FileInfo.FileName',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [128],
                    message: '最大长度为128',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], AttachmentInfo13b8Entity.prototype, "fileName", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'FileSize',
            dataField: 'fileSize',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'FileInfo.FileSize',
        }),
        tslib_1.__metadata("design:type", Object)
    ], AttachmentInfo13b8Entity.prototype, "fileSize", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'FileCreateTime',
            dataField: 'fileCreateTime',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'FileInfo.FileCreateTime',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], AttachmentInfo13b8Entity.prototype, "fileCreateTime", void 0);
    AttachmentInfo13b8Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "FileInfo",
            nodeCode: "fileInfo"
        })
    ], AttachmentInfo13b8Entity);
    return AttachmentInfo13b8Entity;
}(Entity));
export { AttachmentInfo13b8Entity };
