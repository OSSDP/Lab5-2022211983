
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';
import { BXMXEntity } from './bxmxentity';
import { BXFJEntity } from './bxfjentity';
import { BillState2870Entity } from './billstate2870entity';
import { ProcessInstanceB04dEntity } from './processinstanceb04dentity';
import { GspUser9392Entity } from './gspuser9392entity';
import { SysOrg2200Entity } from './sysorg2200entity';
import { GspUserB89BEntity } from './gspuserb89bentity';

@NgEntity({
    originalCode: "ROBXD",
    nodeCode: "robxds"
})
export class ROBXDEntity extends Entity {

    @NgField({
        originalDataField: 'ID',
        dataField: 'id',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ID',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    id: string;

    @NgField({
        originalDataField: 'Version',
        dataField: 'version',
        originalDataFieldType: 'DateTime',
        initValue: '0001-01-01T00:00:00',
        path: 'Version',
        enableTimeZone: true,
    })
    version: string;

    @NgField({
        originalDataField: 'BillCode',
        dataField: 'billCode',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'BillCode',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    billCode: string;

    @NgField({
        originalDataField: 'TotalSum',
        dataField: 'totalSum',
        originalDataFieldType: 'Number',
        initValue: 0,
        path: 'TotalSum',
    })
    totalSum: any;

    @NgField({
        originalDataField: 'BillType',
        dataField: 'billType',
        originalDataFieldType: 'Enum',
        defaultValue: '',
        initValue: 'CL',
        path: 'BillType',
    })
    billType: any;

    @NgField({
        originalDataField: 'BillDate',
        dataField: 'billDate',
        originalDataFieldType: 'DateTime',
        initValue: '0001-01-01T00:00:00',
        path: 'BillDate',
        enableTimeZone: true,
    })
    billDate: string;

    @NgField({
        originalDataField: 'ProjectID',
        dataField: 'projectID',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ProjectID',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    projectID: string;

    @NgField({
        originalDataField: 'BillNote',
        dataField: 'billNote',
        originalDataFieldType: 'Text',
        initValue: '',
        path: 'BillNote',
    })
    billNote: any;

    @NgField({
        originalDataField: 'AuditStatus',
        dataField: 'auditStatus',
        originalDataFieldType: 'Enum',
        defaultValue: '',
        initValue: 'None',
        path: 'AuditStatus',
    })
    auditStatus: any;

    @NgList({
        dataField: 'bxmxs',
        originalDataField: '',
        type: BXMXEntity

    })

    bxmxs: EntityList<BXMXEntity>;
    @NgList({
        dataField: 'bxfjs',
        originalDataField: '',
        type: BXFJEntity

    })

    bxfjs: EntityList<BXFJEntity>;
    @NgObject({
        dataField: 'billStatus',
        originalDataField: 'BillStatus',
        type: BillState2870Entity
    })
    billStatus: BillState2870Entity;
    @NgObject({
        dataField: 'processInstance',
        originalDataField: 'ProcessInstance',
        type: ProcessInstanceB04dEntity
    })
    processInstance: ProcessInstanceB04dEntity;
    @NgObject({
        dataField: 'employeeID',
        originalDataField: 'EmployeeID',
        type: GspUser9392Entity
    })
    employeeID: GspUser9392Entity;
    @NgObject({
        dataField: 'domainID',
        originalDataField: 'DomainID',
        type: SysOrg2200Entity
    })
    domainID: SysOrg2200Entity;
    @NgObject({
        dataField: 'projectMrg',
        originalDataField: 'ProjectMrg',
        type: GspUserB89BEntity
    })
    projectMrg: GspUserB89BEntity;
}