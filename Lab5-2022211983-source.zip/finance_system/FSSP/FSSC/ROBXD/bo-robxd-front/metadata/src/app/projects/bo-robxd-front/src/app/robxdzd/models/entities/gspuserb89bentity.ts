
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';

@NgEntity({
    originalCode: "ProjectMrg",
    nodeCode: "projectMrg"
})
export class GspUserB89BEntity extends Entity {

    @NgField({
        originalDataField: 'ProjectMrg',
        dataField: 'projectMrg',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ProjectMrg.ProjectMrg',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    projectMrg: string;

    @NgField({
        originalDataField: 'Code',
        dataField: 'projectMrg_Code',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ProjectMrg.ProjectMrg_Code',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    projectMrg_Code: string;

    @NgField({
        originalDataField: 'Name',
        dataField: 'projectMrg_Name',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ProjectMrg.ProjectMrg_Name',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    projectMrg_Name: string;

}