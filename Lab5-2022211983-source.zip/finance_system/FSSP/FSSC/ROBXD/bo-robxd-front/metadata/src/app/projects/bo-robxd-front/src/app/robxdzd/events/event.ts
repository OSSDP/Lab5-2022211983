
import { Injectable } from "@angular/core";
import { NgDeclaration, Declaration } from "@farris/devkit";

@Injectable()
export class EventDeclaration extends Declaration {
}