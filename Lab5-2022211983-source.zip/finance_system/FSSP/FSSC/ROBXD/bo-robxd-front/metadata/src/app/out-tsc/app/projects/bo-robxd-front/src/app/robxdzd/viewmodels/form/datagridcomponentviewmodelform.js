import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'employeeID.employeeID_Name',
            name: "{{employeeID_EmployeeID_Name_92cf4bc8_z3gp}}",
            binding: 'employeeID.employeeID_Name',
            defaultI18nValue: '名称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "employeeID_EmployeeID_Name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'domainID.domainID_name',
            name: "{{domainID_DomainID_name_07bc3b93_ww7l}}",
            binding: 'domainID.domainID_name',
            defaultI18nValue: '名称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "domainID_DomainID_name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'billCode',
            name: "{{billCode_3925b61c_sm0r}}",
            binding: 'billCode',
            defaultI18nValue: '单据编号',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "billCode", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'totalSum',
            name: "{{totalSum_d0e31067_0oxy}}",
            binding: 'totalSum',
            defaultI18nValue: '报账金额',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "totalSum", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'billType',
            name: "{{billType_d72718fc_aasu}}",
            binding: 'billType',
            defaultI18nValue: '报销类型',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "billType", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'billDate',
            name: "{{billDate_d661f798_zzmf}}",
            binding: 'billDate',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '制单日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "billDate", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'projectID',
            name: "{{projectID_56817a3e_2wb3}}",
            binding: 'projectID',
            defaultI18nValue: '所属项目',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "projectID", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'projectMrg.projectMrg_Name',
            name: "{{projectMrg_ProjectMrg_Name_15516310_80qd}}",
            binding: 'projectMrg.projectMrg_Name',
            defaultI18nValue: '名称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "projectMrg_ProjectMrg_Name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'auditStatus',
            name: "{{auditStatus_bb2ab5e5_4xqs}}",
            binding: 'auditStatus',
            defaultI18nValue: '稽核状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "auditStatus", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '报销单',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
