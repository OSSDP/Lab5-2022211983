import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState } from '@farris/devkit';
var BxmxComponentViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(BxmxComponentViewmodelUIState, _super);
    function BxmxComponentViewmodelUIState() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BxmxComponentViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], BxmxComponentViewmodelUIState);
    return BxmxComponentViewmodelUIState;
}(UIState));
export { BxmxComponentViewmodelUIState };
