import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var SysOrg2200Entity = /** @class */ (function (_super) {
    tslib_1.__extends(SysOrg2200Entity, _super);
    function SysOrg2200Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'DomainID',
            dataField: 'domainID',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'DomainID.DomainID',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SysOrg2200Entity.prototype, "domainID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'code',
            dataField: 'domainID_code',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'DomainID.DomainID_code',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [100],
                    message: '最大长度为100',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SysOrg2200Entity.prototype, "domainID_code", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'name',
            dataField: 'domainID_name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'DomainID.DomainID_name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [100],
                    message: '最大长度为100',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SysOrg2200Entity.prototype, "domainID_name", void 0);
    SysOrg2200Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "DomainID",
            nodeCode: "domainID"
        })
    ], SysOrg2200Entity);
    return SysOrg2200Entity;
}(Entity));
export { SysOrg2200Entity };
