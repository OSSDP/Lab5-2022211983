import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var BillState18daEntity = /** @class */ (function (_super) {
    tslib_1.__extends(BillState18daEntity, _super);
    function BillState18daEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillState',
            dataField: 'billState',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'Billing',
            path: 'BillStatus.BillState',
        }),
        tslib_1.__metadata("design:type", Object)
    ], BillState18daEntity.prototype, "billState", void 0);
    BillState18daEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "BillStatus",
            nodeCode: "billStatus"
        })
    ], BillState18daEntity);
    return BillState18daEntity;
}(Entity));
export { BillState18daEntity };
