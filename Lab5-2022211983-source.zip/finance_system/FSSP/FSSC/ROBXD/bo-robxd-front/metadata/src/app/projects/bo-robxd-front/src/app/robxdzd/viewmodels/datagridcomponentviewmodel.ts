
import { Injectable } from '@angular/core';
import { ViewModel, NgCommand } from '@farris/devkit';
import { Observable } from 'rxjs';

@Injectable()
export class DataGridComponentViewmodel extends ViewModel {
    public bindingPath = '/';
    // farrisDataGrid列集合定义 在对应component中赋值
    public dataGridColumns:any;
    // datGrid 列集合名称 用以bindData使用
    public dataGridColumnsName:string;

    public dom = {
  "dataGrid": {
    "type": "DataGrid",
    "resourceId": "dataGrid",
    "visible": {
      "useQuote": false,
      "isExpression": false,
      "value": true
    },
    "id": "dataGrid",
    "size": {},
    "readonly": {
      "useQuote": false,
      "isExpression": false,
      "value": false
    },
    "fields": [
      {
        "type": "GridField",
        "resourceId": "employeeID_EmployeeID_Name_92cf4bc8_z3gp",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "employeeID_EmployeeID_Name_92cf4bc8_z3gp",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "employeeID_EmployeeID_Name",
          "isExpression": false,
          "value": "employeeID_EmployeeID_Name"
        },
        "dataField": "employeeID.employeeID_Name",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "名称",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "domainID_DomainID_name_07bc3b93_ww7l",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "domainID_DomainID_name_07bc3b93_ww7l",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "domainID_DomainID_name",
          "isExpression": false,
          "value": "domainID_DomainID_name"
        },
        "dataField": "domainID.domainID_name",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "名称",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "billCode_3925b61c_sm0r",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "billCode_3925b61c_sm0r",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "billCode",
          "isExpression": false,
          "value": "billCode"
        },
        "dataField": "billCode",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "单据编号",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "totalSum_d0e31067_0oxy",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "totalSum_d0e31067_0oxy",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "totalSum",
          "isExpression": false,
          "value": "totalSum"
        },
        "dataField": "totalSum",
        "dataType": "number",
        "multiLanguage": false,
        "caption": "报账金额",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "number",
          "precision": 2,
          "thousand": ",",
          "decimal": "."
        }
      },
      {
        "type": "GridField",
        "resourceId": "billType_d72718fc_aasu",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "billType_d72718fc_aasu",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "billType",
          "isExpression": false,
          "value": "billType"
        },
        "dataField": "billType",
        "dataType": "enum",
        "multiLanguage": false,
        "caption": "报销类型",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "enumData": [
          {
            "name": "差旅费",
            "value": "CL"
          },
          {
            "name": "交通费",
            "value": "JT"
          },
          {
            "name": "手机费",
            "value": "SJ"
          }
        ],
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "billDate_d661f798_zzmf",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "billDate_d661f798_zzmf",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "billDate",
          "isExpression": false,
          "value": "billDate"
        },
        "dataField": "billDate",
        "dataType": "datetime",
        "multiLanguage": false,
        "caption": "制单日期",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "date",
          "dateFormat": "yyyy-MM-dd HH:mm:ss"
        }
      },
      {
        "type": "GridField",
        "resourceId": "projectID_56817a3e_2wb3",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "projectID_56817a3e_2wb3",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "projectID",
          "isExpression": false,
          "value": "projectID"
        },
        "dataField": "projectID",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "所属项目",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "projectMrg_ProjectMrg_Name_15516310_80qd",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "projectMrg_ProjectMrg_Name_15516310_80qd",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "projectMrg_ProjectMrg_Name",
          "isExpression": false,
          "value": "projectMrg_ProjectMrg_Name"
        },
        "dataField": "projectMrg.projectMrg_Name",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "名称",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "auditStatus_bb2ab5e5_4xqs",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "auditStatus_bb2ab5e5_4xqs",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "auditStatus",
          "isExpression": false,
          "value": "auditStatus"
        },
        "dataField": "auditStatus",
        "dataType": "enum",
        "multiLanguage": false,
        "caption": "稽核状态",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "enumData": [
          {
            "name": "未稽核",
            "value": "None"
          },
          {
            "name": "稽核通过",
            "value": "Passed"
          },
          {
            "name": "稽核不通过",
            "value": "Reject"
          }
        ],
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      }
    ],
    "multiSelect": false,
    "showLineNumber": false,
    "lineNumberTitle": "#",
    "groupTotalText": "Total",
    "filterable": false,
    "groupable": false,
    "rowClass": ""
  }
};
    @NgCommand({
        name: 'ChangePage1',
        params: {
            loadCommandName: 'Load1',
            loadCommandFrameId: 'root-component'
        },
        paramDescriptions: {
            loadCommandName: { type: 'string' },
            loadCommandFrameId: { type: 'string' }
        }
    })
    public ChangePage1(commandParam?: any): Observable<any> { return; }

}