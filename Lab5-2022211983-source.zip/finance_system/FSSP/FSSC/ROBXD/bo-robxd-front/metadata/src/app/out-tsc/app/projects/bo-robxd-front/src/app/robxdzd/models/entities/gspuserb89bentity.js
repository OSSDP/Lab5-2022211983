import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var GspUserB89BEntity = /** @class */ (function (_super) {
    tslib_1.__extends(GspUserB89BEntity, _super);
    function GspUserB89BEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ProjectMrg',
            dataField: 'projectMrg',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProjectMrg.ProjectMrg',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GspUserB89BEntity.prototype, "projectMrg", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Code',
            dataField: 'projectMrg_Code',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProjectMrg.ProjectMrg_Code',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GspUserB89BEntity.prototype, "projectMrg_Code", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Name',
            dataField: 'projectMrg_Name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProjectMrg.ProjectMrg_Name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GspUserB89BEntity.prototype, "projectMrg_Name", void 0);
    GspUserB89BEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "ProjectMrg",
            nodeCode: "projectMrg"
        })
    ], GspUserB89BEntity);
    return GspUserB89BEntity;
}(Entity));
export { GspUserB89BEntity };
