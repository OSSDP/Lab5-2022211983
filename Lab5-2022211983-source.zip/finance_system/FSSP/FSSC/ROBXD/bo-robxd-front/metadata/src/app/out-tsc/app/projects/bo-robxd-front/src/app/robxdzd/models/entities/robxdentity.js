import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, EntityList, NgList, NgEntity } from '@farris/devkit';
import { BXMXEntity } from './bxmxentity';
import { BXFJEntity } from './bxfjentity';
import { BillState18daEntity } from './billstate18daentity';
import { ProcessInstanceD4e7Entity } from './processinstanced4e7entity';
import { GspUser9392Entity } from './gspuser9392entity';
import { SysOrg2200Entity } from './sysorg2200entity';
import { GspUserB89BEntity } from './gspuserb89bentity';
var ROBXDEntity = /** @class */ (function (_super) {
    tslib_1.__extends(ROBXDEntity, _super);
    function ROBXDEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ROBXDEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], ROBXDEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillCode',
            dataField: 'billCode',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'BillCode',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ROBXDEntity.prototype, "billCode", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'TotalSum',
            dataField: 'totalSum',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'TotalSum',
        }),
        tslib_1.__metadata("design:type", Object)
    ], ROBXDEntity.prototype, "totalSum", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillType',
            dataField: 'billType',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'CL',
            path: 'BillType',
        }),
        tslib_1.__metadata("design:type", Object)
    ], ROBXDEntity.prototype, "billType", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillDate',
            dataField: 'billDate',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'BillDate',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], ROBXDEntity.prototype, "billDate", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ProjectID',
            dataField: 'projectID',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProjectID',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ROBXDEntity.prototype, "projectID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillNote',
            dataField: 'billNote',
            originalDataFieldType: 'Text',
            initValue: '',
            path: 'BillNote',
        }),
        tslib_1.__metadata("design:type", Object)
    ], ROBXDEntity.prototype, "billNote", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'AuditStatus',
            dataField: 'auditStatus',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'None',
            path: 'AuditStatus',
        }),
        tslib_1.__metadata("design:type", Object)
    ], ROBXDEntity.prototype, "auditStatus", void 0);
    tslib_1.__decorate([
        NgList({
            dataField: 'bxmxs',
            originalDataField: '',
            type: BXMXEntity
        }),
        tslib_1.__metadata("design:type", EntityList)
    ], ROBXDEntity.prototype, "bxmxs", void 0);
    tslib_1.__decorate([
        NgList({
            dataField: 'bxfjs',
            originalDataField: '',
            type: BXFJEntity
        }),
        tslib_1.__metadata("design:type", EntityList)
    ], ROBXDEntity.prototype, "bxfjs", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'billStatus',
            originalDataField: 'BillStatus',
            type: BillState18daEntity
        }),
        tslib_1.__metadata("design:type", BillState18daEntity)
    ], ROBXDEntity.prototype, "billStatus", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'processInstance',
            originalDataField: 'ProcessInstance',
            type: ProcessInstanceD4e7Entity
        }),
        tslib_1.__metadata("design:type", ProcessInstanceD4e7Entity)
    ], ROBXDEntity.prototype, "processInstance", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'employeeID',
            originalDataField: 'EmployeeID',
            type: GspUser9392Entity
        }),
        tslib_1.__metadata("design:type", GspUser9392Entity)
    ], ROBXDEntity.prototype, "employeeID", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'domainID',
            originalDataField: 'DomainID',
            type: SysOrg2200Entity
        }),
        tslib_1.__metadata("design:type", SysOrg2200Entity)
    ], ROBXDEntity.prototype, "domainID", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'projectMrg',
            originalDataField: 'ProjectMrg',
            type: GspUserB89BEntity
        }),
        tslib_1.__metadata("design:type", GspUserB89BEntity)
    ], ROBXDEntity.prototype, "projectMrg", void 0);
    ROBXDEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "ROBXD",
            nodeCode: "robxds"
        })
    ], ROBXDEntity);
    return ROBXDEntity;
}(Entity));
export { ROBXDEntity };
