import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ViewModel, NgCommand } from '@farris/devkit';
import { Observable } from 'rxjs';
var ɵ0 = { type: 'string' };
var BxfjComponentViewmodel = /** @class */ (function (_super) {
    tslib_1.__extends(BxfjComponentViewmodel, _super);
    function BxfjComponentViewmodel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bindingPath = '/bxfjs';
        _this.dom = {
            "dataGrid_bxfj": {
                "type": "DataGrid",
                "resourceId": "dataGrid_bxfj",
                "visible": {
                    "useQuote": false,
                    "isExpression": false,
                    "value": true
                },
                "id": "dataGrid_bxfj",
                "size": {},
                "readonly": {
                    "useQuote": false,
                    "isExpression": false,
                    "value": false
                },
                "fields": [
                    {
                        "type": "GridField",
                        "resourceId": "fileInfo_FileName_13b8d5a4_k9t2",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "fileInfo_FileName_13b8d5a4_k9t2",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "fileInfo_FileName",
                            "isExpression": false,
                            "value": "fileInfo_FileName"
                        },
                        "dataField": "fileInfo.fileName",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "附件名称",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "fileInfo_FileName_13b8d5a4_dxhk",
                            "defaultI18nValue": "文本",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "fileInfo_FileName_13b8d5a4_dxhk",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "fileInfo_FileName",
                                "isExpression": false,
                                "value": "fileInfo_FileName"
                            },
                            "disable": false,
                            "maxLength": 128,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "fileInfo_FileSize_13b8d5a4_rswt",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "fileInfo_FileSize_13b8d5a4_rswt",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "fileInfo_FileSize",
                            "isExpression": false,
                            "value": "fileInfo_FileSize"
                        },
                        "dataField": "fileInfo.fileSize",
                        "dataType": "number",
                        "multiLanguage": false,
                        "caption": "附件大小",
                        "editor": {
                            "type": "FarrisNumberSpinner",
                            "isTextArea": true,
                            "resourceId": "fileInfo_FileSize_13b8d5a4_41y8",
                            "defaultI18nValue": "数值框",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "fileInfo_FileSize_13b8d5a4_41y8",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "fileInfo_FileSize",
                                "isExpression": false,
                                "value": "fileInfo_FileSize"
                            },
                            "disable": false,
                            "step": 1,
                            "useThousands": true,
                            "textAlign": "left",
                            "precision": 8
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "formatter": {
                            "type": "number",
                            "precision": 8,
                            "thousand": ",",
                            "decimal": "."
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "fileInfo_FileCreateTime_13b8d5a4_8how",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "fileInfo_FileCreateTime_13b8d5a4_8how",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "fileInfo_FileCreateTime",
                            "isExpression": false,
                            "value": "fileInfo_FileCreateTime"
                        },
                        "dataField": "fileInfo.fileCreateTime",
                        "dataType": "datetime",
                        "multiLanguage": false,
                        "caption": "附件上传时间",
                        "editor": {
                            "type": "EditableField",
                            "disable": false,
                            "editable": true,
                            "dateRange": false,
                            "showTime": true,
                            "title": "日期选择",
                            "showType": 1,
                            "locale": "zh-cn",
                            "dateFormat": "yyyy-MM-dd HH:mm:ss",
                            "placeHolder": "",
                            "linkedLabelEnabled": false,
                            "disableDates": [],
                            "returnType": "Date",
                            "useDefault": false,
                            "showWeekNumbers": false,
                            "dateRangeDatesDelimiter": "~",
                            "shortcuts": [],
                            "holdPlace": false,
                            "returnFormat": "yyyy-MM-dd HH:mm:ss",
                            "titleWidth": null,
                            "localization": false,
                            "isTextArea": true,
                            "resourceId": "fileInfo_FileCreateTime_13b8d5a4_6d2b",
                            "defaultI18nValue": "日期选择",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "fileInfo_FileCreateTime_13b8d5a4_6d2b",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "fileInfo_FileCreateTime",
                                "isExpression": false,
                                "value": "fileInfo_FileCreateTime"
                            }
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "formatter": {
                            "type": "date",
                            "dateFormat": "yyyy-MM-dd HH:mm:ss"
                        }
                    }
                ],
                "multiSelect": false,
                "editable": "viewModel.stateMachine['editable']",
                "showLineNumber": false,
                "lineNumberTitle": "#",
                "groupTotalText": "Total",
                "filterable": false,
                "groupable": false,
                "rowClass": ""
            }
        };
        return _this;
    }
    BxfjComponentViewmodel.prototype.bxfjAddItem1 = function (commandParam) { return; };
    BxfjComponentViewmodel.prototype.bxfjRemoveItem1 = function (commandParam) { return; };
    tslib_1.__decorate([
        NgCommand({
            name: 'bxfjAddItem1',
            params: {}
        }),
        tslib_1.__metadata("design:type", Function),
        tslib_1.__metadata("design:paramtypes", [Object]),
        tslib_1.__metadata("design:returntype", Observable)
    ], BxfjComponentViewmodel.prototype, "bxfjAddItem1", null);
    tslib_1.__decorate([
        NgCommand({
            name: 'bxfjRemoveItem1',
            params: {
                id: '{DATA~/#{bxfj-component}/bxfjs/id}'
            },
            paramDescriptions: {
                id: ɵ0
            }
        }),
        tslib_1.__metadata("design:type", Function),
        tslib_1.__metadata("design:paramtypes", [Object]),
        tslib_1.__metadata("design:returntype", Observable)
    ], BxfjComponentViewmodel.prototype, "bxfjRemoveItem1", null);
    BxfjComponentViewmodel = tslib_1.__decorate([
        Injectable()
    ], BxfjComponentViewmodel);
    return BxfjComponentViewmodel;
}(ViewModel));
export { BxfjComponentViewmodel };
export { ɵ0 };
