import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var BxmxComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BxmxComponentViewmodelForm, _super);
    function BxmxComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'billDetailDate',
            name: "{{billDetailDate_de1b482a_kjtu}}",
            binding: 'billDetailDate',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '费用日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BxmxComponentViewmodelForm.prototype, "billDetailDate", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'billDetailAmount',
            name: "{{billDetailAmount_d32147ad_6cyu}}",
            binding: 'billDetailAmount',
            updateOn: 'blur',
            defaultI18nValue: '报销金额',
            validRules: [
                {
                    type: 'maxValue',
                    constraints: [1.7976931348623157e+308],
                },
                {
                    type: 'minValue',
                    constraints: [-1.7976931348623157e+308],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BxmxComponentViewmodelForm.prototype, "billDetailAmount", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'billDetailNote',
            name: "{{billDetailNote_c74d35e4_e9lj}}",
            binding: 'billDetailNote',
            updateOn: 'blur',
            defaultI18nValue: '费用说明',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BxmxComponentViewmodelForm.prototype, "billDetailNote", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'invoiceNO',
            name: "{{invoiceNO_36484678_u7ss}}",
            binding: 'invoiceNO',
            updateOn: 'blur',
            defaultI18nValue: '发票号码',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BxmxComponentViewmodelForm.prototype, "invoiceNO", void 0);
    BxmxComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '报销明细',
            enableValidate: true
        }),
        Injectable()
    ], BxmxComponentViewmodelForm);
    return BxmxComponentViewmodelForm;
}(Form));
export { BxmxComponentViewmodelForm };
