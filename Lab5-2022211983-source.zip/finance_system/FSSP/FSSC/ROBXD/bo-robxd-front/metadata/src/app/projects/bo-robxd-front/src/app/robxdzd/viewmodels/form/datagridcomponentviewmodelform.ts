
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '报销单',
    enableValidate: false
})

@Injectable()
export class DataGridComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'employeeID.employeeID_Name',
        name: "{{employeeID_EmployeeID_Name_92cf4bc8_z3gp}}",
        binding: 'employeeID.employeeID_Name',
        defaultI18nValue: '名称',
    })
    employeeID_EmployeeID_Name: FormControl;

    @NgFormControl({
        id: 'domainID.domainID_name',
        name: "{{domainID_DomainID_name_07bc3b93_ww7l}}",
        binding: 'domainID.domainID_name',
        defaultI18nValue: '名称',
    })
    domainID_DomainID_name: FormControl;

    @NgFormControl({
        id: 'billCode',
        name: "{{billCode_3925b61c_sm0r}}",
        binding: 'billCode',
        defaultI18nValue: '单据编号',
    })
    billCode: FormControl;

    @NgFormControl({
        id: 'totalSum',
        name: "{{totalSum_d0e31067_0oxy}}",
        binding: 'totalSum',
        defaultI18nValue: '报账金额',
    })
    totalSum: FormControl;

    @NgFormControl({
        id: 'billType',
        name: "{{billType_d72718fc_aasu}}",
        binding: 'billType',
        defaultI18nValue: '报销类型',
    })
    billType: FormControl;

    @NgFormControl({
        id: 'billDate',
        name: "{{billDate_d661f798_zzmf}}",
        binding: 'billDate',
        valueConverter: new DateConverter('yyyy-MM-dd'),
        defaultI18nValue: '制单日期',
    })
    billDate: FormControl;

    @NgFormControl({
        id: 'projectID',
        name: "{{projectID_56817a3e_2wb3}}",
        binding: 'projectID',
        defaultI18nValue: '所属项目',
    })
    projectID: FormControl;

    @NgFormControl({
        id: 'projectMrg.projectMrg_Name',
        name: "{{projectMrg_ProjectMrg_Name_15516310_80qd}}",
        binding: 'projectMrg.projectMrg_Name',
        defaultI18nValue: '名称',
    })
    projectMrg_ProjectMrg_Name: FormControl;

    @NgFormControl({
        id: 'auditStatus',
        name: "{{auditStatus_bb2ab5e5_4xqs}}",
        binding: 'auditStatus',
        defaultI18nValue: '稽核状态',
    })
    auditStatus: FormControl;

}