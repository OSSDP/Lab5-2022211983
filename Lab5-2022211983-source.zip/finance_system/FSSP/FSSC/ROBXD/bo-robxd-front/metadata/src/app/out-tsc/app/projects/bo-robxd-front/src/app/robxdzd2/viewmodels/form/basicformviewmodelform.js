import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'employeeID_EmployeeID_Name_f710e92e_v81c',
            name: "{{employeeID_EmployeeID_Name_f710e92e_v81c}}",
            binding: 'employeeID.employeeID_Name',
            updateOn: 'blur',
            defaultI18nValue: '报销人',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "employeeID_EmployeeID_Name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'domainID_DomainID_name_c2a814ca_9qcb',
            name: "{{domainID_DomainID_name_c2a814ca_9qcb}}",
            binding: 'domainID.domainID_name',
            updateOn: 'blur',
            defaultI18nValue: '所属部门',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "domainID_DomainID_name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'billCode_c2735656_chny',
            name: "{{billCode_c2735656_chny}}",
            binding: 'billCode',
            updateOn: 'blur',
            defaultI18nValue: '单据编号',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "billCode", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'totalSum_09c990b5_t8l4',
            name: "{{totalSum_09c990b5_t8l4}}",
            binding: 'totalSum',
            updateOn: 'blur',
            defaultI18nValue: '报账金额',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "totalSum", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'billType_239d6d48_c4sc',
            name: "{{billType_239d6d48_c4sc}}",
            binding: 'billType',
            updateOn: 'change',
            defaultI18nValue: '报销类型',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "billType", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'billDate_4c58ce86_fnxw',
            name: "{{billDate_4c58ce86_fnxw}}",
            binding: 'billDate',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '制单日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "billDate", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'projectID_c87a3547_rb43',
            name: "{{projectID_c87a3547_rb43}}",
            binding: 'projectID',
            updateOn: 'blur',
            defaultI18nValue: '所属项目',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "projectID", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'billNote_909f28e5_gsdr',
            name: "{{billNote_909f28e5_gsdr}}",
            binding: 'billNote',
            updateOn: 'blur',
            defaultI18nValue: '报销说明',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "billNote", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'projectMrg_ProjectMrg_Name_5679472b_am0p',
            name: "{{projectMrg_ProjectMrg_Name_5679472b_am0p}}",
            binding: 'projectMrg.projectMrg_Name',
            updateOn: 'blur',
            defaultI18nValue: '项目经理',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "projectMrg_ProjectMrg_Name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'auditStatus_2db7782a_6vjc',
            name: "{{auditStatus_2db7782a_6vjc}}",
            binding: 'auditStatus',
            updateOn: 'change',
            defaultI18nValue: '稽核状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "auditStatus", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '报销单',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
