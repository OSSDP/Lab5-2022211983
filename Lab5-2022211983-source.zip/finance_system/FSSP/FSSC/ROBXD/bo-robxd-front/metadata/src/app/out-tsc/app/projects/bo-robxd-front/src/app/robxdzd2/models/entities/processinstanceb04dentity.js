import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var ProcessInstanceB04dEntity = /** @class */ (function (_super) {
    tslib_1.__extends(ProcessInstanceB04dEntity, _super);
    function ProcessInstanceB04dEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ProcessInstance',
            dataField: 'processInstance',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProcessInstance.ProcessInstance',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ProcessInstanceB04dEntity.prototype, "processInstance", void 0);
    ProcessInstanceB04dEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "ProcessInstance",
            nodeCode: "processInstance"
        })
    ], ProcessInstanceB04dEntity);
    return ProcessInstanceB04dEntity;
}(Entity));
export { ProcessInstanceB04dEntity };
