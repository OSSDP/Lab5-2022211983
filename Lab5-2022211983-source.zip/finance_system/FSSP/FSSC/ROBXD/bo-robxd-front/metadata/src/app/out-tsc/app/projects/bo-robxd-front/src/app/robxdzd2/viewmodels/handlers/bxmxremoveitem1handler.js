import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { CommandHandler, NgCommandHandler } from '@farris/devkit';
import { SubListDataService as SubListDataService1 } from '@farris/command-services';
var bxmxRemoveItem1Handler = /** @class */ (function (_super) {
    tslib_1.__extends(bxmxRemoveItem1Handler, _super);
    function bxmxRemoveItem1Handler(_SubListDataService1) {
        var _this = _super.call(this) || this;
        _this._SubListDataService1 = _SubListDataService1;
        return _this;
    }
    bxmxRemoveItem1Handler.prototype.schedule = function () {
        var _this = this;
        this.addTask('remove', function (context) {
            var args = [
                '{COMMAND~/params/id}',
                '{COMMAND~/params/successMsg}'
            ];
            return _this.invoke(_this._SubListDataService1, 'remove', args, context);
        });
    };
    bxmxRemoveItem1Handler = tslib_1.__decorate([
        Injectable(),
        NgCommandHandler({
            commandName: 'bxmxRemoveItem1'
        }),
        tslib_1.__metadata("design:paramtypes", [SubListDataService1])
    ], bxmxRemoveItem1Handler);
    return bxmxRemoveItem1Handler;
}(CommandHandler));
export { bxmxRemoveItem1Handler };
