import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState } from '@farris/devkit';
var BxfjComponentViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(BxfjComponentViewmodelUIState, _super);
    function BxfjComponentViewmodelUIState() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BxfjComponentViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], BxfjComponentViewmodelUIState);
    return BxfjComponentViewmodelUIState;
}(UIState));
export { BxfjComponentViewmodelUIState };
