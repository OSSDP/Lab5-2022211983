
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '报销明细',
    enableValidate: true
})

@Injectable()
export class BxmxComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'billDetailDate',
        name: "{{billDetailDate_de1b482a_kjtu}}",
        binding: 'billDetailDate',
        updateOn: 'blur',
        valueConverter: new DateConverter('yyyy-MM-dd'),
        defaultI18nValue: '费用日期',
    })
    billDetailDate: FormControl;

    @NgFormControl({
        id: 'billDetailAmount',
        name: "{{billDetailAmount_d32147ad_6cyu}}",
        binding: 'billDetailAmount',
        updateOn: 'blur',
        defaultI18nValue: '报销金额',
        validRules: [
            {
                type: 'maxValue',
                constraints: [1.7976931348623157e+308],
            },
            {
                type: 'minValue',
                constraints: [-1.7976931348623157e+308],
            }
        ]
    })
    billDetailAmount: FormControl;

    @NgFormControl({
        id: 'billDetailNote',
        name: "{{billDetailNote_c74d35e4_e9lj}}",
        binding: 'billDetailNote',
        updateOn: 'blur',
        defaultI18nValue: '费用说明',
    })
    billDetailNote: FormControl;

    @NgFormControl({
        id: 'invoiceNO',
        name: "{{invoiceNO_36484678_u7ss}}",
        binding: 'invoiceNO',
        updateOn: 'blur',
        defaultI18nValue: '发票号码',
    })
    invoiceNO: FormControl;

}