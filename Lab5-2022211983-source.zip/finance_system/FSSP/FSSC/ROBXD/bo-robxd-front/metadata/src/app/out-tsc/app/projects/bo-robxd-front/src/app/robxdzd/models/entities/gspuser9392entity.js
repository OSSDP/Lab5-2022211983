import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var GspUser9392Entity = /** @class */ (function (_super) {
    tslib_1.__extends(GspUser9392Entity, _super);
    function GspUser9392Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'EmployeeID',
            dataField: 'employeeID',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'EmployeeID.EmployeeID',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GspUser9392Entity.prototype, "employeeID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Code',
            dataField: 'employeeID_Code',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'EmployeeID.EmployeeID_Code',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GspUser9392Entity.prototype, "employeeID_Code", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Name',
            dataField: 'employeeID_Name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'EmployeeID.EmployeeID_Name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GspUser9392Entity.prototype, "employeeID_Name", void 0);
    GspUser9392Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "EmployeeID",
            nodeCode: "employeeID"
        })
    ], GspUser9392Entity);
    return GspUser9392Entity;
}(Entity));
export { GspUser9392Entity };
