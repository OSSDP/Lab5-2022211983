import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TranslateResolveService } from './lang/lang-pipe';
import { RootComponent } from './components/root-component/rootcomponent';
var routes = [
    {
        path: '',
        component: RootComponent,
        children: [],
        resolve: {
            'translate': TranslateResolveService
        }
    }
];
var ROBXDZD2RoutingModule = /** @class */ (function () {
    function ROBXDZD2RoutingModule() {
    }
    ROBXDZD2RoutingModule = tslib_1.__decorate([
        NgModule({
            imports: [
                RouterModule.forChild(routes)
            ],
            exports: [
                RouterModule
            ]
        })
    ], ROBXDZD2RoutingModule);
    return ROBXDZD2RoutingModule;
}());
export { ROBXDZD2RoutingModule };
