
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '报销单',
    enableValidate: true
})

@Injectable()
export class BasicFormViewmodelForm extends Form {
    @NgFormControl({
        id: 'employeeID_EmployeeID_Name_f710e92e_v81c',
        name: "{{employeeID_EmployeeID_Name_f710e92e_v81c}}",
        binding: 'employeeID.employeeID_Name',
        updateOn: 'blur',
        defaultI18nValue: '报销人',
    })
    employeeID_EmployeeID_Name: FormControl;

    @NgFormControl({
        id: 'domainID_DomainID_name_c2a814ca_9qcb',
        name: "{{domainID_DomainID_name_c2a814ca_9qcb}}",
        binding: 'domainID.domainID_name',
        updateOn: 'blur',
        defaultI18nValue: '所属部门',
    })
    domainID_DomainID_name: FormControl;

    @NgFormControl({
        id: 'billCode_c2735656_chny',
        name: "{{billCode_c2735656_chny}}",
        binding: 'billCode',
        updateOn: 'blur',
        defaultI18nValue: '单据编号',
    })
    billCode: FormControl;

    @NgFormControl({
        id: 'totalSum_09c990b5_t8l4',
        name: "{{totalSum_09c990b5_t8l4}}",
        binding: 'totalSum',
        updateOn: 'blur',
        defaultI18nValue: '报账金额',
    })
    totalSum: FormControl;

    @NgFormControl({
        id: 'billType_239d6d48_c4sc',
        name: "{{billType_239d6d48_c4sc}}",
        binding: 'billType',
        updateOn: 'change',
        defaultI18nValue: '报销类型',
        validRules: [
            {
                type: 'required',
                constraints: [true],
            }
        ]
    })
    billType: FormControl;

    @NgFormControl({
        id: 'billDate_4c58ce86_fnxw',
        name: "{{billDate_4c58ce86_fnxw}}",
        binding: 'billDate',
        updateOn: 'blur',
        valueConverter: new DateConverter('yyyy-MM-dd'),
        defaultI18nValue: '制单日期',
    })
    billDate: FormControl;

    @NgFormControl({
        id: 'projectID_c87a3547_rb43',
        name: "{{projectID_c87a3547_rb43}}",
        binding: 'projectID',
        updateOn: 'blur',
        defaultI18nValue: '所属项目',
    })
    projectID: FormControl;

    @NgFormControl({
        id: 'billNote_909f28e5_gsdr',
        name: "{{billNote_909f28e5_gsdr}}",
        binding: 'billNote',
        updateOn: 'blur',
        defaultI18nValue: '报销说明',
    })
    billNote: FormControl;

    @NgFormControl({
        id: 'projectMrg_ProjectMrg_Name_5679472b_am0p',
        name: "{{projectMrg_ProjectMrg_Name_5679472b_am0p}}",
        binding: 'projectMrg.projectMrg_Name',
        updateOn: 'blur',
        defaultI18nValue: '项目经理',
    })
    projectMrg_ProjectMrg_Name: FormControl;

    @NgFormControl({
        id: 'auditStatus_2db7782a_6vjc',
        name: "{{auditStatus_2db7782a_6vjc}}",
        binding: 'auditStatus',
        updateOn: 'change',
        defaultI18nValue: '稽核状态',
    })
    auditStatus: FormControl;

}