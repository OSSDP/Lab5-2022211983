import * as tslib_1 from "tslib";
import { Component, Injector, ViewChild, HostBinding, ElementRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Form, FrameComponent, FARRIS_DEVKIT_FRAME_PROVIDERS, ViewModel, FRAME_ID, BindingData, Repository, UIState, EXCEPTION_HANDLER, NAMESPACE } from '@farris/devkit';
import { FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS, ComponentManagerService } from '@farris/command-services';
import { KeybindingService } from '@farris/command-services';
import { ActivatedRoute, Router } from '@angular/router';
import { FrmI18nSettingService } from '@gsp-sys/rtf-common';
import { DomSanitizer } from '@angular/platform-browser';
import { FocusInvalidService } from '@farris/command-services';
import { LookupGridComponent } from '@farris/ui-lookup';
import { BefLookupRestService, DefaultComboHttpService } from '@farris/bef';
import { ServerSideToken } from '@farris/ui-lookup';
import { ComboServerSideToken } from '@farris/ui-combo-list';
import { WizardService } from '@farris/ui-wizard';
import { LocalizationService } from "@farris/command-services";
import { BasicFormViewmodel } from '../../viewmodels/basicformviewmodel';
import { ROBXDRepository } from '../../models/robxdrepository';
import { LangService } from '../../lang/lang-pipe';
import { BasicFormViewmodelForm } from '../../viewmodels/form/basicformviewmodelform';
import { BasicFormViewmodelUIState } from '../../viewmodels/uistate/basicformviewmodeluistate';
var BasicFormComponent = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormComponent, _super);
    function BasicFormComponent(wizardSer, keybindingService, langService, route, router, rootElement, localizationService, frmI18nSettingService, focusInvalidService, componentManagerService, sanitizer, injector) {
        var _this = _super.call(this, injector) || this;
        _this.wizardSer = wizardSer;
        _this.keybindingService = keybindingService;
        _this.langService = langService;
        _this.route = route;
        _this.router = router;
        _this.rootElement = rootElement;
        _this.localizationService = localizationService;
        _this.frmI18nSettingService = frmI18nSettingService;
        _this.focusInvalidService = focusInvalidService;
        _this.componentManagerService = componentManagerService;
        _this.sanitizer = sanitizer;
        _this.injector = injector;
        _this.cls = 'f-struct-wrapper ';
        _this.lang = "";
        _this.size = {};
        _this.enabledLanguageList = [];
        _this.tabsToolbarStates = new BehaviorSubject({});
        _this.tabsToolbarVisibleStates = new BehaviorSubject({});
        _this.FieldSetTitlea0d05cac69c64deebe17d6bc58da50fd = _this.langService.transform('a0d05cac-69c6-4dee-be17-d6bc58da50fd', _this.lang, "基础信息");
        _this.FieldSetCollapseTexta0d05cac69c64deebe17d6bc58da50fd = _this.langService.transform('FieldSet/a0d05cac-69c6-4dee-be17-d6bc58da50fd/collapseText', _this.lang, "");
        _this.FieldSetExpandTexta0d05cac69c64deebe17d6bc58da50fd = _this.langService.transform('FieldSet/a0d05cac-69c6-4dee-be17-d6bc58da50fd/expandText', _this.lang, "");
        _this.FieldSetTitlecea1199fcfce45d9afc429298c3dd860 = _this.langService.transform('cea1199f-cfce-45d9-afc4-29298c3dd860', _this.lang, "高级信息");
        _this.FieldSetCollapseTextcea1199fcfce45d9afc429298c3dd860 = _this.langService.transform('FieldSet/cea1199f-cfce-45d9-afc4-29298c3dd860/collapseText', _this.lang, "");
        _this.FieldSetExpandTextcea1199fcfce45d9afc429298c3dd860 = _this.langService.transform('FieldSet/cea1199f-cfce-45d9-afc4-29298c3dd860/expandText', _this.lang, "");
        _this.SectionbasicformsectionMainTitle = _this.langService.transform('Section/basic-form-section/mainTitle', _this.lang, "基本信息");
        _this.SectionbasicformsectionSubTitle = _this.langService.transform('Section/basic-form-section/subTitle', _this.lang, "");
        _this.LookupEditemployeeIDEmployeeIDNamef710e92ev81cDialogTitle = _this.langService.transform('LookupEdit/employeeID_EmployeeID_Name_f710e92e_v81c/dialogTitle', _this.lang, "");
        _this.employeeID_EmployeeID_Name_f710e92e_v81c_PlaceHolder = _this.langService.transform('LookupEdit/employeeID_EmployeeID_Name_f710e92e_v81c/placeHolder', _this.lang, "");
        _this.LookupEditdomainIDDomainIDnamec2a814ca9qcbDialogTitle = _this.langService.transform('LookupEdit/domainID_DomainID_name_c2a814ca_9qcb/dialogTitle', _this.lang, "");
        _this.domainID_DomainID_name_c2a814ca_9qcb_PlaceHolder = _this.langService.transform('LookupEdit/domainID_DomainID_name_c2a814ca_9qcb/placeHolder', _this.lang, "");
        _this.LookupEditprojectMrgProjectMrgName5679472bam0pDialogTitle = _this.langService.transform('LookupEdit/projectMrg_ProjectMrg_Name_5679472b_am0p/dialogTitle', _this.lang, "");
        _this.projectMrg_ProjectMrg_Name_5679472b_am0p_PlaceHolder = _this.langService.transform('LookupEdit/projectMrg_ProjectMrg_Name_5679472b_am0p/placeHolder', _this.lang, "");
        _this.totalSum_09c990b5_t8l4_PlaceHolder = _this.langService.transform('NumericBox/totalSum_09c990b5_t8l4/placeHolder', _this.lang, "");
        _this.totalSum09c990b5T8l4TextOptions = {
            "type": "number",
            "useThousands": true,
            "precision": 2,
        };
        _this.billDate_4c58ce86_fnxw_PlaceHolder = _this.langService.transform('DateBox/billDate_4c58ce86_fnxw/placeHolder', _this.lang, "");
        _this.billType_239d6d48_c4scEnumData = [
            {
                "name": _this.langService.transform('EnumField/billType_239d6d48_c4sc/enumData/CL', _this.lang, "差旅费"),
                "value": "CL"
            },
            {
                "name": _this.langService.transform('EnumField/billType_239d6d48_c4sc/enumData/JT', _this.lang, "交通费"),
                "value": "JT"
            },
            {
                "name": _this.langService.transform('EnumField/billType_239d6d48_c4sc/enumData/SJ', _this.lang, "手机费"),
                "value": "SJ"
            }
        ];
        _this.billType_239d6d48_c4sc_PlaceHolder = _this.langService.transform('EnumField/billType_239d6d48_c4sc/placeHolder', _this.lang, "");
        _this.auditStatus_2db7782a_6vjcEnumData = [
            {
                "name": _this.langService.transform('EnumField/auditStatus_2db7782a_6vjc/enumData/None', _this.lang, "未稽核"),
                "value": "None"
            },
            {
                "name": _this.langService.transform('EnumField/auditStatus_2db7782a_6vjc/enumData/Passed', _this.lang, "稽核通过"),
                "value": "Passed"
            },
            {
                "name": _this.langService.transform('EnumField/auditStatus_2db7782a_6vjc/enumData/Reject', _this.lang, "稽核不通过"),
                "value": "Reject"
            }
        ];
        _this.auditStatus_2db7782a_6vjc_PlaceHolder = _this.langService.transform('EnumField/auditStatus_2db7782a_6vjc/placeHolder', _this.lang, "");
        _this.billCode_c2735656_chny_PlaceHolder = _this.langService.transform('TextBox/billCode_c2735656_chny/placeHolder', _this.lang, "");
        _this.projectID_c87a3547_rb43_PlaceHolder = _this.langService.transform('TextBox/projectID_c87a3547_rb43/placeHolder', _this.lang, "");
        _this.lang = localStorage.getItem('languageCode') || "zh-CHS";
        _this.viewModel.verifycationChanged.subscribe(function (verifyInformations) {
            _this.focusInvalidService.focusInvalidInput(verifyInformations, _this.rootElement);
        });
        if (_this.frmI18nSettingService) {
            var i18nSetting = _this.frmI18nSettingService.getSetting();
            if (i18nSetting && i18nSetting.languages && i18nSetting.languages.length > 0) {
                i18nSetting.languages.forEach(function (item) {
                    _this.enabledLanguageList.push({
                        code: item.code,
                        name: item.name
                    });
                });
            }
            else {
                console.warn("get current enable languages is null. if this occurs,please ensure the form into the framework.");
                _this.enabledLanguageList.push({ "code": "en", "name": "English" });
                _this.enabledLanguageList.push({ "code": "zh-CHS", "name": "中文简体" });
            }
        }
        return _this;
    }
    BasicFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.keybindingService) {
            this.viewModel.keybindingMap.forEach(function (keyBinding, method) {
                _this.keybindingService.register(keyBinding, function () {
                    return _this.viewModel[method]();
                });
            });
        }
        this.onFormLoad();
    };
    BasicFormComponent.prototype.ngAfterViewInit = function () {
        this.componentManagerService.appendControl('employeeID_EmployeeID_Name_f710e92e_v81c', this.employeeID_EmployeeID_Name_f710e92e_v81c);
        this.componentManagerService.appendControl('domainID_DomainID_name_c2a814ca_9qcb', this.domainID_DomainID_name_c2a814ca_9qcb);
        this.componentManagerService.appendControl('projectMrg_ProjectMrg_Name_5679472b_am0p', this.projectMrg_ProjectMrg_Name_5679472b_am0p);
    };
    BasicFormComponent.prototype.ngOnDestroy = function () {
        // 增加表单的自我销毁
        this.context.dispose && this.context.dispose();
        this.viewModel = null;
        this.context = null;
        this.subscription = null;
        this.declaration = null;
        this.wizardSer = null;
        this.keybindingService = null;
        this.langService = null;
        this.route = null;
        this.router = null;
        this.rootElement = null;
        this.localizationService = null;
        this.frmI18nSettingService = null;
        this.focusInvalidService = null;
        this.componentManagerService.clear();
        this.componentManagerService = null;
        this.sanitizer = null;
        this.injector = null;
        this.enabledLanguageList = [];
    };
    BasicFormComponent.prototype.handleSizeChange = function (size) {
        this.size = size;
    };
    BasicFormComponent.prototype.onFormLoad = function () {
    };
    tslib_1.__decorate([
        ViewChild('employeeID_EmployeeID_Name_f710e92e_v81c'),
        tslib_1.__metadata("design:type", LookupGridComponent)
    ], BasicFormComponent.prototype, "employeeID_EmployeeID_Name_f710e92e_v81c", void 0);
    tslib_1.__decorate([
        ViewChild('domainID_DomainID_name_c2a814ca_9qcb'),
        tslib_1.__metadata("design:type", LookupGridComponent)
    ], BasicFormComponent.prototype, "domainID_DomainID_name_c2a814ca_9qcb", void 0);
    tslib_1.__decorate([
        ViewChild('projectMrg_ProjectMrg_Name_5679472b_am0p'),
        tslib_1.__metadata("design:type", LookupGridComponent)
    ], BasicFormComponent.prototype, "projectMrg_ProjectMrg_Name_5679472b_am0p", void 0);
    tslib_1.__decorate([
        HostBinding('class'),
        tslib_1.__metadata("design:type", Object)
    ], BasicFormComponent.prototype, "cls", void 0);
    BasicFormComponent = tslib_1.__decorate([
        Component({
            selector: 'app-basicformcomponent',
            templateUrl: './basicformcomponent.html',
            styleUrls: ['./basicformcomponent.scss'],
            providers: [
                FARRIS_DEVKIT_FRAME_PROVIDERS,
                FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS,
                { provide: FRAME_ID, useValue: 'basic-form-component' },
                { provide: BindingData, useClass: BindingData },
                { provide: Repository, useExisting: ROBXDRepository },
                LangService,
                { provide: NAMESPACE, useValue: '' },
                { provide: ServerSideToken, useClass: BefLookupRestService },
                { provide: ComboServerSideToken, useClass: DefaultComboHttpService },
                { provide: Form, useClass: BasicFormViewmodelForm },
                { provide: UIState, useClass: BasicFormViewmodelUIState },
                { provide: ViewModel, useClass: BasicFormViewmodel },
                { provide: EXCEPTION_HANDLER, useValue: null },
            ]
        }),
        tslib_1.__metadata("design:paramtypes", [WizardService,
            KeybindingService,
            LangService,
            ActivatedRoute,
            Router,
            ElementRef,
            LocalizationService,
            FrmI18nSettingService,
            FocusInvalidService,
            ComponentManagerService,
            DomSanitizer,
            Injector])
    ], BasicFormComponent);
    return BasicFormComponent;
}(FrameComponent));
export { BasicFormComponent };
