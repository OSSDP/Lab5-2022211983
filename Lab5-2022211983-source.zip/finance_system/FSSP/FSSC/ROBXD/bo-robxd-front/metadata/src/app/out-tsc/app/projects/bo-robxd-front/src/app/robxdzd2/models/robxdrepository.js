import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { ROBXDEntity } from './entities/robxdentity';
import { ROBXDProxy } from './robxdproxy';
var ROBXDRepository = /** @class */ (function (_super) {
    tslib_1.__extends(ROBXDRepository, _super);
    function ROBXDRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'ROBXDRepository';
        _this.paginationInfo = {};
        _this.proxy = injector.get(ROBXDProxy, null);
        return _this;
    }
    ROBXDRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/fssp/fssc/v1.0/robxdzd2_frm',
            entityType: ROBXDEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], ROBXDRepository);
    return ROBXDRepository;
}(BefRepository));
export { ROBXDRepository };
