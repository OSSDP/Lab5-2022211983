import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BefProxy, UriService } from '@farris/bef';
var ROBXDProxy = /** @class */ (function (_super) {
    tslib_1.__extends(ROBXDProxy, _super);
    function ROBXDProxy(httpClient, uriService) {
        var _this = _super.call(this, httpClient, uriService) || this;
        _this.apiUrl = 'api/fssp/fssc/v1.0/robxdzd2_frm';
        _this.baseUri = uriService.extendUri(_this.apiUrl);
        return _this;
    }
    ROBXDProxy = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [HttpClient,
            UriService])
    ], ROBXDProxy);
    return ROBXDProxy;
}(BefProxy));
export { ROBXDProxy };
