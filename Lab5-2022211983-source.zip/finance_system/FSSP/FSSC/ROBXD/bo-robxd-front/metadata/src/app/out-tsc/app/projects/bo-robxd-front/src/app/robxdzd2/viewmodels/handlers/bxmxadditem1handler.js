import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { CommandHandler, NgCommandHandler } from '@farris/devkit';
import { SubListDataService as SubListDataService1 } from '@farris/command-services';
var bxmxAddItem1Handler = /** @class */ (function (_super) {
    tslib_1.__extends(bxmxAddItem1Handler, _super);
    function bxmxAddItem1Handler(_SubListDataService1) {
        var _this = _super.call(this) || this;
        _this._SubListDataService1 = _SubListDataService1;
        return _this;
    }
    bxmxAddItem1Handler.prototype.schedule = function () {
        var _this = this;
        this.addTask('add', function (context) {
            var args = [];
            return _this.invoke(_this._SubListDataService1, 'add', args, context);
        });
    };
    bxmxAddItem1Handler = tslib_1.__decorate([
        Injectable(),
        NgCommandHandler({
            commandName: 'bxmxAddItem1'
        }),
        tslib_1.__metadata("design:paramtypes", [SubListDataService1])
    ], bxmxAddItem1Handler);
    return bxmxAddItem1Handler;
}(CommandHandler));
export { bxmxAddItem1Handler };
