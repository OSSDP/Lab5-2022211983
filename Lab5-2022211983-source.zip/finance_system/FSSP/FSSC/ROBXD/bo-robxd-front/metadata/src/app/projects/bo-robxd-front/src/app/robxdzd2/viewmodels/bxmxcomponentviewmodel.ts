
import { Injectable } from '@angular/core';
import { ViewModel, NgCommand } from '@farris/devkit';
import { Observable } from 'rxjs';

@Injectable()
export class BxmxComponentViewmodel extends ViewModel {
    public bindingPath = '/bxmxs';
    // farrisDataGrid列集合定义 在对应component中赋值
    public dataGrid_bxmxColumns:any;
    // datGrid 列集合名称 用以bindData使用
    public dataGridColumnsName:string;

    public dom = {
  "dataGrid_bxmx": {
    "type": "DataGrid",
    "resourceId": "dataGrid_bxmx",
    "visible": {
      "useQuote": false,
      "isExpression": false,
      "value": true
    },
    "id": "dataGrid_bxmx",
    "size": {},
    "readonly": {
      "useQuote": false,
      "isExpression": false,
      "value": false
    },
    "fields": [
      {
        "type": "GridField",
        "resourceId": "billDetailDate_de1b482a_kjtu",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "billDetailDate_de1b482a_kjtu",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "billDetailDate",
          "isExpression": false,
          "value": "billDetailDate"
        },
        "dataField": "billDetailDate",
        "dataType": "datetime",
        "multiLanguage": false,
        "caption": "费用日期",
        "editor": {
          "type": "EditableField",
          "disable": false,
          "editable": true,
          "dateRange": false,
          "showTime": true,
          "title": "日期选择",
          "showType": 1,
          "locale": "zh-cn",
          "dateFormat": "yyyy-MM-dd HH:mm:ss",
          "placeHolder": "",
          "linkedLabelEnabled": false,
          "disableDates": [],
          "returnType": "Date",
          "useDefault": false,
          "showWeekNumbers": false,
          "dateRangeDatesDelimiter": "~",
          "shortcuts": [],
          "holdPlace": false,
          "returnFormat": "yyyy-MM-dd HH:mm:ss",
          "titleWidth": null,
          "localization": false,
          "isTextArea": true,
          "resourceId": "billDetailDate_de1b482a_szk8",
          "defaultI18nValue": "日期选择",
          "visible": {
            "useQuote": false,
            "isExpression": false,
            "value": true
          },
          "id": "billDetailDate_de1b482a_szk8",
          "size": {},
          "readonly": {
            "useQuote": false,
            "isExpression": false,
            "value": false
          },
          "binding": {
            "type": "Form",
            "path": "billDetailDate",
            "isExpression": false,
            "value": "billDetailDate"
          }
        },
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "updateOn": "blur",
        "formatter": {
          "type": "date",
          "dateFormat": "yyyy-MM-dd HH:mm:ss"
        }
      },
      {
        "type": "GridField",
        "resourceId": "billDetailAmount_d32147ad_6cyu",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "billDetailAmount_d32147ad_6cyu",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "billDetailAmount",
          "isExpression": false,
          "value": "billDetailAmount"
        },
        "dataField": "billDetailAmount",
        "dataType": "number",
        "multiLanguage": false,
        "caption": "报销金额",
        "editor": {
          "type": "FarrisNumberSpinner",
          "isTextArea": true,
          "resourceId": "billDetailAmount_d32147ad_egoy",
          "defaultI18nValue": "数值框",
          "visible": {
            "useQuote": false,
            "isExpression": false,
            "value": true
          },
          "id": "billDetailAmount_d32147ad_egoy",
          "size": {},
          "readonly": {
            "useQuote": false,
            "isExpression": false,
            "value": false
          },
          "binding": {
            "type": "Form",
            "path": "billDetailAmount",
            "isExpression": false,
            "value": "billDetailAmount"
          },
          "disable": false,
          "step": 1,
          "useThousands": true,
          "textAlign": "left",
          "precision": 2
        },
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "updateOn": "blur",
        "formatter": {
          "type": "number",
          "precision": 2,
          "thousand": ",",
          "decimal": "."
        }
      },
      {
        "type": "GridField",
        "resourceId": "billDetailNote_c74d35e4_e9lj",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "billDetailNote_c74d35e4_e9lj",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "billDetailNote",
          "isExpression": false,
          "value": "billDetailNote"
        },
        "dataField": "billDetailNote",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "费用说明",
        "editor": {
          "type": "MultiTextBox",
          "isTextArea": true,
          "resourceId": "billDetailNote_c74d35e4_474o",
          "defaultI18nValue": "多行文本框",
          "visible": {
            "useQuote": false,
            "isExpression": false,
            "value": true
          },
          "id": "billDetailNote_c74d35e4_474o",
          "size": {},
          "readonly": {
            "useQuote": false,
            "isExpression": false,
            "value": false
          },
          "binding": {
            "type": "Form",
            "path": "billDetailNote",
            "isExpression": false,
            "value": "billDetailNote"
          },
          "disable": false,
          "maxLength": 0
        },
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "updateOn": "blur",
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "invoiceNO_36484678_u7ss",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "invoiceNO_36484678_u7ss",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "invoiceNO",
          "isExpression": false,
          "value": "invoiceNO"
        },
        "dataField": "invoiceNO",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "发票号码",
        "editor": {
          "type": "TextBox",
          "isTextArea": true,
          "resourceId": "invoiceNO_36484678_4936",
          "defaultI18nValue": "文本",
          "visible": {
            "useQuote": false,
            "isExpression": false,
            "value": true
          },
          "id": "invoiceNO_36484678_4936",
          "size": {},
          "readonly": {
            "useQuote": false,
            "isExpression": false,
            "value": false
          },
          "binding": {
            "type": "Form",
            "path": "invoiceNO",
            "isExpression": false,
            "value": "invoiceNO"
          },
          "disable": false,
          "maxLength": 36,
          "isPassword": false,
          "enableViewPassword": false
        },
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "updateOn": "blur",
        "formatter": {
          "type": "none"
        }
      }
    ],
    "multiSelect": false,
    "editable": "viewModel.stateMachine['editable']",
    "showLineNumber": false,
    "lineNumberTitle": "#",
    "groupTotalText": "Total",
    "filterable": false,
    "groupable": false,
    "rowClass": ""
  }
};
    @NgCommand({
        name: 'bxmxAddItem1',
        params: {
        }
    })
    public bxmxAddItem1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'bxmxRemoveItem1',
        params: {
            id: '{DATA~/#{bxmx-component}/bxmxs/id}'
        },
        paramDescriptions: {
            id: { type: 'string' }
        }
    })
    public bxmxRemoveItem1(commandParam?: any): Observable<any> { return; }

}