import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var ProcessInstanceD4e7Entity = /** @class */ (function (_super) {
    tslib_1.__extends(ProcessInstanceD4e7Entity, _super);
    function ProcessInstanceD4e7Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ProcessInstance',
            dataField: 'processInstance',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProcessInstance.ProcessInstance',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ProcessInstanceD4e7Entity.prototype, "processInstance", void 0);
    ProcessInstanceD4e7Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "ProcessInstance",
            nodeCode: "processInstance"
        })
    ], ProcessInstanceD4e7Entity);
    return ProcessInstanceD4e7Entity;
}(Entity));
export { ProcessInstanceD4e7Entity };
