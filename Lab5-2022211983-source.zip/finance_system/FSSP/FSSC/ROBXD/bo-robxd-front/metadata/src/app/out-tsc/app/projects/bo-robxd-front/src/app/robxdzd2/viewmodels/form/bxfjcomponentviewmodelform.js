import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var BxfjComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BxfjComponentViewmodelForm, _super);
    function BxfjComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'fileInfo.fileName',
            name: "{{fileInfo_FileName_13b8d5a4_k9t2}}",
            binding: 'fileInfo.fileName',
            updateOn: 'blur',
            defaultI18nValue: '附件名称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BxfjComponentViewmodelForm.prototype, "fileInfo_FileName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'fileInfo.fileSize',
            name: "{{fileInfo_FileSize_13b8d5a4_rswt}}",
            binding: 'fileInfo.fileSize',
            updateOn: 'blur',
            defaultI18nValue: '附件大小',
            validRules: [
                {
                    type: 'maxValue',
                    constraints: [1.7976931348623157e+308],
                },
                {
                    type: 'minValue',
                    constraints: [-1.7976931348623157e+308],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BxfjComponentViewmodelForm.prototype, "fileInfo_FileSize", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'fileInfo.fileCreateTime',
            name: "{{fileInfo_FileCreateTime_13b8d5a4_8how}}",
            binding: 'fileInfo.fileCreateTime',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '附件上传时间',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BxfjComponentViewmodelForm.prototype, "fileInfo_FileCreateTime", void 0);
    BxfjComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '报销附件',
            enableValidate: true
        }),
        Injectable()
    ], BxfjComponentViewmodelForm);
    return BxfjComponentViewmodelForm;
}(Form));
export { BxfjComponentViewmodelForm };
