import * as tslib_1 from "tslib";
import { Pipe, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { of } from 'rxjs';
import { catchError, switchMap } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
export function createTranslateLoader(http, version) {
    var versionSuffix = "";
    if (version) {
        versionSuffix = "?v=" + version;
    }
    return new TranslateHttpLoader(http, '/apps/fssp/fssc/web/bo-robxd-front/robxdzd2/i18n/', '.json' + versionSuffix);
}
export var lang = { "zh-CHS": { "TextBox/employeeID_EmployeeID_Name_f710e92e_v81c/placeHolder": "", "TextBox/domainID_DomainID_name_c2a814ca_9qcb/placeHolder": "", "TextBox/projectMrg_ProjectMrg_Name_5679472b_am0p/placeHolder": "", "root-component": "", "root-layout": "", "page-header": "", "header-nav": "", "header-title-container": "", "page-header-title": "", "page-header-toolbar": "", "button-add": "新增", "button-edit": "编辑", "button-save": "保存", "button-cancel": "取消", "button-approve": "提交审批", "button-cancel-approve": "取消提交审批", "main-container": "", "like-card-container": "", "basic-form-component-ref": "", "detail-container": "", "detail-section": "", "Section/detail-section/mainTitle": "", "Section/detail-section/subTitle": "", "detail-tab": "", "bxmx-tab-page": "报销明细", "bxmx-component-ref": "", "bxmx-tab-toolbar": "", "bxmxAddButton": "新增", "bxmxRemoveButton": "删除", "bxfj-tab-page": "报销附件", "bxfj-component-ref": "", "bxfj-tab-toolbar": "", "bxfjAddButton": "新增", "bxfjRemoveButton": "删除", "basic-form-component": "", "basic-form-section": "", "Section/basic-form-section/mainTitle": "基本信息", "Section/basic-form-section/subTitle": "", "basic-form-layout": "", "a0d05cac-69c6-4dee-be17-d6bc58da50fd": "基础信息", "FieldSet/a0d05cac-69c6-4dee-be17-d6bc58da50fd/collapseText": "", "FieldSet/a0d05cac-69c6-4dee-be17-d6bc58da50fd/expandText": "", "employeeID_EmployeeID_Name_f710e92e_v81c": "报销人", "LookupEdit/employeeID_EmployeeID_Name_f710e92e_v81c/placeHolder": "", "LookupEdit/employeeID_EmployeeID_Name_f710e92e_v81c/dialogTitle": "", "domainID_DomainID_name_c2a814ca_9qcb": "所属部门", "LookupEdit/domainID_DomainID_name_c2a814ca_9qcb/placeHolder": "", "LookupEdit/domainID_DomainID_name_c2a814ca_9qcb/dialogTitle": "", "billCode_c2735656_chny": "单据编号", "TextBox/billCode_c2735656_chny/placeHolder": "", "totalSum_09c990b5_t8l4": "报账金额", "NumberSpinner/totalSum_09c990b5_t8l4/placeHolder": "", "billType_239d6d48_c4sc": "报销类型", "EnumField/billType_239d6d48_c4sc/placeHolder": "", "EnumField/billType_239d6d48_c4sc/enumData/CL": "差旅费", "EnumField/billType_239d6d48_c4sc/enumData/JT": "交通费", "EnumField/billType_239d6d48_c4sc/enumData/SJ": "手机费", "cea1199f-cfce-45d9-afc4-29298c3dd860": "高级信息", "FieldSet/cea1199f-cfce-45d9-afc4-29298c3dd860/collapseText": "", "FieldSet/cea1199f-cfce-45d9-afc4-29298c3dd860/expandText": "", "billDate_4c58ce86_fnxw": "制单日期", "DateBox/billDate_4c58ce86_fnxw/placeHolder": "", "projectID_c87a3547_rb43": "所属项目", "TextBox/projectID_c87a3547_rb43/placeHolder": "", "projectMrg_ProjectMrg_Name_5679472b_am0p": "项目经理", "LookupEdit/projectMrg_ProjectMrg_Name_5679472b_am0p/placeHolder": "", "LookupEdit/projectMrg_ProjectMrg_Name_5679472b_am0p/dialogTitle": "", "auditStatus_2db7782a_6vjc": "稽核状态", "EnumField/auditStatus_2db7782a_6vjc/placeHolder": "", "EnumField/auditStatus_2db7782a_6vjc/enumData/None": "未稽核", "EnumField/auditStatus_2db7782a_6vjc/enumData/Passed": "稽核通过", "EnumField/auditStatus_2db7782a_6vjc/enumData/Reject": "稽核不通过", "billNote_909f28e5_gsdr": "报销说明", "MultiTextBox/billNote_909f28e5_gsdr/placeHolder": "", "bxmx-component": "", "bxmx-component-layout": "", "dataGrid_bxmx": "", "DataGrid/dataGrid_bxmx/lineNumberTitle": "", "DataGrid/dataGrid_bxmx/OperateEditButton": "编辑", "DataGrid/dataGrid_bxmx/OperateDeleteButton": "删除", "DataGrid/dataGrid_bxmx/OperateColumn": "操作", "billDetailDate_de1b482a_kjtu": "费用日期", "GridField/billDetailDate_de1b482a_kjtu/editor/billDetailDate_de1b482a_szk8": "日期选择", "GridField/billDetailDate_de1b482a_kjtu/editor/DateBox/billDetailDate_de1b482a_szk8/placeHolder": "", "billDetailAmount_d32147ad_6cyu": "报销金额", "GridField/billDetailAmount_d32147ad_6cyu/editor/billDetailAmount_d32147ad_egoy": "数值框", "GridField/billDetailAmount_d32147ad_6cyu/editor/NumberSpinner/billDetailAmount_d32147ad_egoy/placeHolder": "", "billDetailNote_c74d35e4_e9lj": "费用说明", "GridField/billDetailNote_c74d35e4_e9lj/editor/billDetailNote_c74d35e4_474o": "多行文本框", "GridField/billDetailNote_c74d35e4_e9lj/editor/MultiTextBox/billDetailNote_c74d35e4_474o/placeHolder": "", "invoiceNO_36484678_u7ss": "发票号码", "GridField/invoiceNO_36484678_u7ss/editor/invoiceNO_36484678_4936": "文本", "GridField/invoiceNO_36484678_u7ss/editor/TextBox/invoiceNO_36484678_4936/placeHolder": "", "bxfj-component": "", "bxfj-component-layout": "", "dataGrid_bxfj": "", "DataGrid/dataGrid_bxfj/lineNumberTitle": "", "DataGrid/dataGrid_bxfj/OperateEditButton": "编辑", "DataGrid/dataGrid_bxfj/OperateDeleteButton": "删除", "DataGrid/dataGrid_bxfj/OperateColumn": "操作", "fileInfo_FileName_13b8d5a4_k9t2": "附件名称", "GridField/fileInfo_FileName_13b8d5a4_k9t2/editor/fileInfo_FileName_13b8d5a4_dxhk": "文本", "GridField/fileInfo_FileName_13b8d5a4_k9t2/editor/TextBox/fileInfo_FileName_13b8d5a4_dxhk/placeHolder": "", "fileInfo_FileSize_13b8d5a4_rswt": "附件大小", "GridField/fileInfo_FileSize_13b8d5a4_rswt/editor/fileInfo_FileSize_13b8d5a4_41y8": "数值框", "GridField/fileInfo_FileSize_13b8d5a4_rswt/editor/NumberSpinner/fileInfo_FileSize_13b8d5a4_41y8/placeHolder": "", "fileInfo_FileCreateTime_13b8d5a4_8how": "附件上传时间", "GridField/fileInfo_FileCreateTime_13b8d5a4_8how/editor/fileInfo_FileCreateTime_13b8d5a4_6d2b": "日期选择", "GridField/fileInfo_FileCreateTime_13b8d5a4_8how/editor/DateBox/fileInfo_FileCreateTime_13b8d5a4_6d2b/placeHolder": "" } };
var LangPipe = /** @class */ (function () {
    function LangPipe(translate, http) {
        this.translate = translate;
        this.http = http;
    }
    LangPipe.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangPipe = tslib_1.__decorate([
        Pipe({ name: 'lang' }),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], LangPipe);
    return LangPipe;
}());
export { LangPipe };
var SafeHtmlPipe = /** @class */ (function () {
    function SafeHtmlPipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    SafeHtmlPipe.prototype.transform = function (url) {
        if (!url) {
            url = "";
        }
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    };
    SafeHtmlPipe = tslib_1.__decorate([
        Pipe({ name: 'safeHtml' }),
        tslib_1.__metadata("design:paramtypes", [DomSanitizer])
    ], SafeHtmlPipe);
    return SafeHtmlPipe;
}());
export { SafeHtmlPipe };
var LangService = /** @class */ (function () {
    function LangService(translate) {
        this.translate = translate;
    }
    LangService.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangService.prototype.getCurrentLanguage = function () {
        return this.translate.currentLang;
    };
    LangService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService])
    ], LangService);
    return LangService;
}());
export { LangService };
var TranslateResolveService = /** @class */ (function () {
    function TranslateResolveService(translate, http) {
        this.translate = translate;
        this.http = http;
        translate.defaultLang = 'zh-CHS';
        translate.setTranslation('zh-CHS', lang['zh-CHS']);
    }
    TranslateResolveService.prototype.resolve = function (route, state) {
        var _this = this;
        var langCode = localStorage.getItem('languageCode');
        if (!langCode) {
            langCode = "zh-CHS";
        }
        if (langCode == "zh-CHS" || (this.translate.defaultLang === langCode && this.translate.currentLoader == createTranslateLoader(this.http, null))) {
            this.translate.setTranslation('zh-CHS', lang['zh-CHS']);
            return of(this.translate[langCode]);
        }
        else {
            var httpOb = this.http.get("/apps/fssp/fssc/web/bo-robxd-front/version.json?v=" + new Date().getTime()).pipe(switchMap(function (data) {
                var currentVersion = null;
                if (data instanceof Array) {
                    var versionKey_1 = "robxdzd2/" + langCode + ".json";
                    data.forEach(function (item) {
                        if (item.category == "i18n" && item.key == versionKey_1) {
                            currentVersion = item.value;
                        }
                    });
                }
                _this.translate.defaultLang = langCode;
                _this.translate.currentLang = langCode;
                _this.translate.currentLoader = createTranslateLoader(_this.http, currentVersion);
                var tran = _this.translate.getTranslation(langCode).pipe(catchError(function (err) {
                    console.error("read resource file failed,please check!!! " + err);
                    return of(err);
                }));
                return tran;
            }));
            return httpOb;
        }
    };
    TranslateResolveService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], TranslateResolveService);
    return TranslateResolveService;
}());
export { TranslateResolveService };
